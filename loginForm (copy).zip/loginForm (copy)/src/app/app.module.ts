import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FormComponent } from './form/form.component';
import { FooterComponent } from './footer/footer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes} from '@angular/router';
import { ModelComponent } from './model/model.component';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpClientModule } from '@angular/common/http';
import { User } from './user';
import { AuthenticationserviceService } from './services/authenticationservice.service';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormComponent,
    FooterComponent,
    DashboardComponent,
    ModelComponent,

  ],
  imports: [
    RouterModule.forRoot([
      {
        path:'dashboard',
        component:DashboardComponent
      },
      {
        path:'**',
        component:FormComponent
      }
    ]),
    BrowserModule,
    HttpClientModule,
  ],
  providers: [AuthenticationserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
